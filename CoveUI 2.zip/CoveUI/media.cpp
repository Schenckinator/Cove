#include "media.h"
#include "ui_media.h"
#include "covemenu.h"
#include "playlistmanager.h"
#include <QLineEdit>
#include <QInputDialog>
#include <QListWidget>
#include <QListWidgetItem>
#include <QDebug>
#include <QMessageBox>
#include <QFileDialog>
#include <QDir>
#include <QFileInfo>
#include <QFile>
#include <QTextStream>
Media::Media(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Media)
{
    ui->setupUi(this);
    setupDisplayManager();

    // m_displayManager = new MediaDisplayManager(this);

    connect(ui->ListofMedia, &QListWidget::itemDoubleClicked,
        this, [this](QListWidgetItem *item) {
    QString title = item->text();
    QString path  = pathForTitle(title);   // reads CSV to find the stored path
    m_displayManager->display(path, this);
    });
    this->setStyleSheet("background-color: white;");

    QStringList media = {
        "The Dark Knight",
        "Inception",
        "Interstellar",
        "The Matrix",
        "Pulp Fiction",
        "Forrest Gump",
        "The Godfather",
        "Fight Club",
        "Goodfellas",
        "The Shawshank Redemption"
    };
    ui->ListofMedia->addItems(media);
}

Media::~Media()
{
    delete ui;
}

void Media::on_uploadMedia_clicked()
{

    // Open a cross-platform file picker (works on Windows, macOS, Linux)
    QString selectedPath = QFileDialog::getOpenFileName(
        this,
        "Select Media File",
        QDir::homePath(),
        "All Media (*.mp4 *.mkv *.avi *.mov *.wmv *.m4v *.mp3 *.wav *.flac *.ogg *.jpg *.jpeg *.png *.gif *.bmp *.tiff);;"
        "Image Files (*.jpg *.jpeg *.png *.gif *.bmp *.tiff);;"
        "Video Files (*.mp4 *.mkv *.avi *.mov *.wmv *.m4v);;"
        "Audio Files (*.mp3 *.wav *.flac *.ogg);;"
        "All Files (*)"
        );

    if (selectedPath.isEmpty())
        return; // User cancelled

    QFileInfo fileInfo(selectedPath);
    QString fileName = fileInfo.fileName();           // e.g. "mymovie.mp4"
    QString nativePath = QDir::toNativeSeparators(selectedPath);
    // ^ Converts to \ on Windows, / on macOS/Linux

    if (mediaExistsInCSV(nativePath)) {
        QMessageBox::warning(this, "Duplicate Media",
                             "\"" + fileName + "\" is already in the list.");
        return;
    }

    writeMediaToCSV(fileName, nativePath);
    ui->ListofMedia->addItem(fileName);




    // bool ok;
    // QString mediaTitle = QInputDialog::getText(
    //     this,
    //     "Add Media",
    //     "Enter media title:",
    //     QLineEdit::Normal,
    //     "",
    //     &ok
    //     );
    // if (ok && !mediaTitle.isEmpty()) {
    //     ui->ListofMedia->addItem(mediaTitle);
    // }

}

void Media::on_ListofMedia_itemClicked(QListWidgetItem *item)
{
    // only selects the item, nothing else
    qDebug() << "Selected:" << item->text();
}

void Media::on_deleteMedia_clicked()
{
    QListWidgetItem *selected = ui->ListofMedia->currentItem();
    if (selected) {
        QMessageBox::StandardButton reply = QMessageBox::question(
            this,
            "Confirm Delete",
            "Remove \"" + selected->text() + "\" from the list?",
            QMessageBox::Yes | QMessageBox::No
            );
        if (reply == QMessageBox::Yes) {
            QString targetName = selected->text();

            // Read all lines, skip the matching one
            QFile file("media.csv");
            QStringList remaining;
            if (file.open(QIODevice::ReadOnly | QIODevice::Text)) {
                QTextStream in(&file);
                while (!in.atEnd()) {
                    QString line = in.readLine().trimmed();
                    QString name = line.section(',', 0, 0).remove('"').trimmed();
                    if (name != targetName)
                        remaining.append(line);
                }
                file.close();
            }

            // Rewrite the file without the deleted entry
            if (file.open(QIODevice::WriteOnly | QIODevice::Text | QIODevice::Truncate)) {
                QTextStream out(&file);
                for (const QString &line : remaining)
                    out << line << "\n";
                file.close();
            }

            delete selected;
        }
    } else {
        QMessageBox::warning(this, "No Selection", "Please select media to delete.");
    }
}

void Media::on_exit_clicked()
{
    CoveMenu *covemenu = new CoveMenu();
    covemenu->show();
    this->close();
}

void Media::on_createPlaylist_clicked()
{
    bool ok;
    QString name = QInputDialog::getText(
        this,
        "Create Playlist",
        "Enter playlist name:",
        QLineEdit::Normal, "", &ok
        );

    if (ok && !name.isEmpty()) {
        PlaylistManager::instance().createPlaylist(name);
        QMessageBox::information(this, "Success",
                                 "Playlist \"" + name + "\" created!");
    }
}

void Media::on_addToPlaylist_clicked()
{
    // check a movie is selected
    QListWidgetItem *selected = ui->ListofMedia->currentItem();
    if (!selected) {
        QMessageBox::warning(this, "No Selection",
                             "Please select a movie first.");
        return;
    }

    // get available playlists
    QStringList playlists = PlaylistManager::instance().getPlaylists();
    if (playlists.isEmpty()) {
        QMessageBox::warning(this, "No Playlists",
                             "Create a playlist first.");
        return;
    }

    // let user pick which playlist to add to
    bool ok;
    QString chosen = QInputDialog::getItem(
        this,
        "Add to Playlist",
        "Select playlist:",
        playlists, 0, false, &ok
        );

    if (ok && !chosen.isEmpty()) {
        PlaylistManager::instance().addToPlaylist(chosen, selected->text());
        QMessageBox::information(this, "Added",
                                 "\"" + selected->text() + "\" added to " + chosen);
    }
}

void Media::on_searchBar_textChanged(const QString &query)
{
    search(query);
}

// ======================= Helpers ========================
void Media::writeMediaToCSV(const QString &fileName, const QString &filePath)
{
    QFile file("media.csv");
    if (!file.open(QIODevice::Append | QIODevice::Text)) {
        QMessageBox::critical(this, "File Error",
                              "Could not open media.csv for writing.");
        return;
    }
    QTextStream out(&file);
    // Wrap fields in quotes to safely handle commas in filenames/paths
    out << "\"" << fileName << "\","
        << "\"" << filePath << "\"\n";
    file.close();
}

bool Media::mediaExistsInCSV(const QString &filePath) const
{
    QFile file("media.csv");
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
        return false;

    QTextStream in(&file);
    while (!in.atEnd()) {
        QString line = in.readLine();
        // Second field (index 1) is the path
        QString existingPath = line.section(',', 1, 1)
                                   .remove('"')
                                   .trimmed();
        if (existingPath == filePath) {
            file.close();
            return true;
        }
    }
    file.close();
    return false;
}

// ===================== Non-UI Management Functions =====================




void Media::search(const QString &query)
{
    if (query.trimmed().isEmpty()) {
        // Reload full list from CSV
        ui->ListofMedia->clear();
        QFile file("media.csv");
        if (file.open(QIODevice::ReadOnly | QIODevice::Text)) {
            QTextStream in(&file);
            while (!in.atEnd()) {
                QString line = in.readLine().trimmed();
                QString name = line.section(',', 0, 0).remove('"').trimmed();
                if (!name.isEmpty())
                    ui->ListofMedia->addItem(name);
            }
            file.close();
        }
        return;
    }
    // Filter list by name
    ui->ListofMedia->clear();
    QFile file("media.csv");
    if (file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QTextStream in(&file);
        while (!in.atEnd()) {
            QString line = in.readLine().trimmed();
            QString name = line.section(',', 0, 0).remove('"').trimmed();
            if (name.contains(query.trimmed(), Qt::CaseInsensitive))
                ui->ListofMedia->addItem(name);
        }
        file.close();
    }
}

void Media::displayMedia(const QStringList &mediaToDisplay)
{
    ui->ListofMedia->clear();
    ui->ListofMedia->addItems(mediaToDisplay);
}


void Media::setupDisplayManager()
{
    m_displayManager = new MediaDisplayManager(this);

    connect(ui->ListofMedia, &QListWidget::itemDoubleClicked,
            this, [this](QListWidgetItem *item) {
                QString path = pathForTitle(item->text());
                m_displayManager->display(path, this);
            });
}

QString Media::pathForTitle(const QString &title) const
{
    QFile file("media.csv");
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
        return {};
    QTextStream in(&file);
    while (!in.atEnd()) {
        QString line = in.readLine().trimmed();
        QString name = line.section(',', 0, 0).remove('"').trimmed();
        if (name == title)
            return line.section(',', 1, 1).remove('"').trimmed();
    }
    return {};
}

