#ifndef LIBRARY_H
#define LIBRARY_H

#include <QWidget>
#include <QListWidgetItem>
#include "MediaDisplayManager.h"

namespace Ui { class Library; }

class Library : public QWidget
{
    Q_OBJECT
public:
    explicit Library(QWidget *parent = nullptr);
    ~Library();

private slots:
    void on_playlistWidget_itemDoubleClicked(QListWidgetItem *item);
    void on_playlistWidget_itemClicked(QListWidgetItem *item);
    void on_refreshPlaylists_clicked();
    void on_deletePlaylist_clicked();
    void on_exit_clicked();
    void on_removeMedia_clicked();
    void on_backToPlaylists_clicked();

private:
    Ui::Library        *ui;
    MediaDisplayManager *m_displayManager;
    QString             m_currentPlaylist; // empty = playlist list view

    void loadPlaylists();
    void showPlaylistContents(const QString &playlistName);

    // Look up the file path for a media title from the user's media CSV
    QString pathForTitle(const QString &title) const;
};

#endif