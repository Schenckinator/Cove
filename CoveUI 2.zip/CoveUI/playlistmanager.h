#ifndef PLAYLISTMANAGER_H
#define PLAYLISTMANAGER_H

#include <QString>
#include <QStringList>
#include <QMap>

class PlaylistManager
{
public:
    // single instance accessible everywhere
    static PlaylistManager& instance() {
        static PlaylistManager pm;
        return pm;
    }

    // create a new playlist
    void createPlaylist(const QString &name) {
        if (!playlists.contains(name))
            playlists[name] = QStringList();
    }

    // add a movie to a playlist
    void addToPlaylist(const QString &playlistName, const QString &movie) {
        if (playlists.contains(playlistName))
            playlists[playlistName].append(movie);
    }

    // get all playlist names
    QStringList getPlaylists() const {
        return playlists.keys();
    }

    // get all movies in a playlist
    QStringList getMedia(const QString &playlistName) const {
        return playlists.value(playlistName);
    }

    // delete a playlist
    void deletePlaylist(const QString &name) {
        playlists.remove(name);
    }

    void removeFromPlaylist(const QString &playlistName, const QString &movie) {
        if (playlists.contains(playlistName))
            playlists[playlistName].removeAll(movie);
    }

private:
    QMap<QString, QStringList> playlists;
};

#endif // PLAYLISTMANAGER_H