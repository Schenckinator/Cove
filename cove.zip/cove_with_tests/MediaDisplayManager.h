#ifndef MEDIADISPLAYMANAGER_H
#define MEDIADISPLAYMANAGER_H

#pragma once
#include <QObject>
#include <QDialog>
#include <QLabel>
#include <QScrollArea>
#include <QPushButton>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QSlider>
#include <QMediaPlayer>
#include <QAudioOutput>
#include <QVideoWidget>
#include <QFileInfo>
#include <QPixmap>
#include <QTimer>

// ── Base viewer dialog all types inherit from ─────────────────────────────────
class BaseMediaDialog : public QDialog
{
    Q_OBJECT
public:
    explicit BaseMediaDialog(const QString &filePath, QWidget *parent = nullptr);
protected:
    QString   m_filePath;
    QString   m_fileName;
    QLabel   *m_titleLabel;
    void      buildTitleBar(QVBoxLayout *layout);
};

// ── Image viewer ──────────────────────────────────────────────────────────────
class ImageViewerDialog : public BaseMediaDialog
{
    Q_OBJECT
public:
    explicit ImageViewerDialog(const QString &filePath, QWidget *parent = nullptr);
private:
    QLabel      *m_imageLabel;
    QScrollArea *m_scrollArea;
    double       m_zoomFactor = 1.0;
    QPixmap      m_original;
    void applyZoom();
private slots:
    void zoomIn();
    void zoomOut();
    void resetZoom();
};

// ── Audio player ──────────────────────────────────────────────────────────────
class AudioPlayerDialog : public BaseMediaDialog
{
    Q_OBJECT
public:
    explicit AudioPlayerDialog(const QString &filePath, QWidget *parent = nullptr);
private:
    QMediaPlayer  *m_player;
    QAudioOutput  *m_audioOutput;
    QPushButton   *m_playPauseBtn;
    QSlider       *m_seekSlider;
    QSlider       *m_volumeSlider;
    QLabel        *m_timeLabel;
    bool           m_seeking = false;
    QString formatTime(qint64 ms);
private slots:
    void togglePlayPause();
    void onPositionChanged(qint64 pos);
    void onDurationChanged(qint64 dur);
    void onStateChanged(QMediaPlayer::PlaybackState state);
};

// ── Video player ──────────────────────────────────────────────────────────────
class VideoPlayerDialog : public BaseMediaDialog
{
    Q_OBJECT
public:
    explicit VideoPlayerDialog(const QString &filePath, QWidget *parent = nullptr);
private:
    QMediaPlayer  *m_player;
    QAudioOutput  *m_audioOutput;
    QVideoWidget  *m_videoWidget;
    QPushButton   *m_playPauseBtn;
    QSlider       *m_seekSlider;
    QSlider       *m_volumeSlider;
    QLabel        *m_timeLabel;
    QString formatTime(qint64 ms);
private slots:
    void togglePlayPause();
    void onPositionChanged(qint64 pos);
    void onDurationChanged(qint64 dur);
    void onStateChanged(QMediaPlayer::PlaybackState state);
};

// ── Display Manager — entry point ─────────────────────────────────────────────
class MediaDisplayManager : public QObject
{
    Q_OBJECT
public:
    enum class MediaType { Image, Audio, Video, Unknown };

    explicit MediaDisplayManager(QObject *parent = nullptr);

    // Call this to open the right viewer for any file path
    void display(const QString &filePath, QWidget *parentWidget = nullptr);

    static MediaType detectType(const QString &filePath);
};
#endif // MEDIADISPLAYMANAGER_H
