#ifndef USERSESSION_H
#define USERSESSION_H

#include <QString>

// Lightweight singleton that stores the currently logged-in username.
// Set once on successful login; read everywhere else (Media, Library, etc.)
class UserSession
{
public:
    static UserSession &instance() {
        static UserSession s;
        return s;
    }

    void setUsername(const QString &username) { m_username = username; }
    QString username() const { return m_username; }

    // Returns the per-user media CSV path, e.g. "media_alice.csv"
    QString mediaCSVPath() const {
        return "media_" + m_username + ".csv";
    }

private:
    UserSession() = default;
    QString m_username;
};

#endif // USERSESSION_H
