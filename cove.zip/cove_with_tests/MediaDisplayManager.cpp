#include "MediaDisplayManager.h"
#include <QMessageBox>
#include <QStyle>

// ─────────────────────────────────────────────────────────────────────────────
// BaseMediaDialog
// ─────────────────────────────────────────────────────────────────────────────
BaseMediaDialog::BaseMediaDialog(const QString &filePath, QWidget *parent)
    : QDialog(parent), m_filePath(filePath)
{
    QFileInfo fi(filePath);
    m_fileName = fi.fileName();
    setWindowTitle(m_fileName);
    setAttribute(Qt::WA_DeleteOnClose);
}

void BaseMediaDialog::buildTitleBar(QVBoxLayout *layout)
{
    m_titleLabel = new QLabel(m_fileName, this);
    m_titleLabel->setAlignment(Qt::AlignCenter);
    m_titleLabel->setStyleSheet(
        "font-size: 14px; font-weight: bold; padding: 6px;"
        "color: #222; border-bottom: 1px solid #ddd;"
        );
    layout->addWidget(m_titleLabel);
}

// ─────────────────────────────────────────────────────────────────────────────
// ImageViewerDialog
// ─────────────────────────────────────────────────────────────────────────────
ImageViewerDialog::ImageViewerDialog(const QString &filePath, QWidget *parent)
    : BaseMediaDialog(filePath, parent)
{
    setMinimumSize(640, 500);

    auto *root = new QVBoxLayout(this);
    buildTitleBar(root);

    m_imageLabel = new QLabel(this);
    m_imageLabel->setAlignment(Qt::AlignCenter);

    m_scrollArea = new QScrollArea(this);
    m_scrollArea->setWidget(m_imageLabel);
    m_scrollArea->setWidgetResizable(false);
    m_scrollArea->setAlignment(Qt::AlignCenter);
    root->addWidget(m_scrollArea, 1);

    // Zoom controls
    auto *zoomRow = new QHBoxLayout();
    auto *zoomIn  = new QPushButton("🔍 +", this);
    auto *zoomOut = new QPushButton("🔍 −", this);
    auto *reset   = new QPushButton("⊡ Fit", this);
    for (auto *b : {zoomIn, zoomOut, reset})
        b->setFixedWidth(80);
    zoomRow->addStretch();
    zoomRow->addWidget(zoomOut);
    zoomRow->addWidget(reset);
    zoomRow->addWidget(zoomIn);
    zoomRow->addStretch();
    root->addLayout(zoomRow);

    connect(zoomIn,  &QPushButton::clicked, this, &ImageViewerDialog::zoomIn);
    connect(zoomOut, &QPushButton::clicked, this, &ImageViewerDialog::zoomOut);
    connect(reset,   &QPushButton::clicked, this, &ImageViewerDialog::resetZoom);

    m_original = QPixmap(filePath);
    if (m_original.isNull()) {
        m_imageLabel->setText("Could not load image.");
    } else {
        applyZoom();
    }
}

void ImageViewerDialog::applyZoom()
{
    QPixmap scaled = m_original.scaled(
        m_original.size() * m_zoomFactor,
        Qt::KeepAspectRatio,
        Qt::SmoothTransformation
        );
    m_imageLabel->setPixmap(scaled);
    m_imageLabel->resize(scaled.size());
}

void ImageViewerDialog::zoomIn()  { m_zoomFactor = qMin(m_zoomFactor + 0.15, 5.0); applyZoom(); }
void ImageViewerDialog::zoomOut() { m_zoomFactor = qMax(m_zoomFactor - 0.15, 0.1); applyZoom(); }
void ImageViewerDialog::resetZoom()
{
    // Fit to scroll area
    QSize avail = m_scrollArea->viewport()->size();
    double scaleW = (double)avail.width()  / m_original.width();
    double scaleH = (double)avail.height() / m_original.height();
    m_zoomFactor  = qMin(scaleW, scaleH);
    applyZoom();
}

// ─────────────────────────────────────────────────────────────────────────────
// Shared player controls builder (lambda-friendly free function)
// ─────────────────────────────────────────────────────────────────────────────
static QString fmtTime(qint64 ms)
{
    qint64 s = ms / 1000;
    return QString("%1:%2").arg(s / 60).arg(s % 60, 2, 10, QChar('0'));
}

// ─────────────────────────────────────────────────────────────────────────────
// AudioPlayerDialog
// ─────────────────────────────────────────────────────────────────────────────
AudioPlayerDialog::AudioPlayerDialog(const QString &filePath, QWidget *parent)
    : BaseMediaDialog(filePath, parent)
{
    setFixedSize(420, 220);

    m_player      = new QMediaPlayer(this);
    m_audioOutput = new QAudioOutput(this);
    m_player->setAudioOutput(m_audioOutput);
    m_audioOutput->setVolume(0.7f);
    m_player->setSource(QUrl::fromLocalFile(filePath));

    auto *root = new QVBoxLayout(this);
    buildTitleBar(root);

    // Seek slider
    m_seekSlider = new QSlider(Qt::Horizontal, this);
    m_seekSlider->setRange(0, 0);
    root->addWidget(m_seekSlider);

    m_timeLabel = new QLabel("0:00 / 0:00", this);
    m_timeLabel->setAlignment(Qt::AlignCenter);
    root->addWidget(m_timeLabel);

    // Controls row
    auto *row = new QHBoxLayout();
    m_playPauseBtn  = new QPushButton("▶ Play", this);
    auto *stopBtn   = new QPushButton("■ Stop", this);
    auto *volLabel  = new QLabel("🔊", this);
    m_volumeSlider  = new QSlider(Qt::Horizontal, this);
    m_volumeSlider->setRange(0, 100);
    m_volumeSlider->setValue(70);
    m_volumeSlider->setMaximumWidth(90);

    row->addWidget(m_playPauseBtn);
    row->addWidget(stopBtn);
    row->addStretch();
    row->addWidget(volLabel);
    row->addWidget(m_volumeSlider);
    root->addLayout(row);

    connect(m_playPauseBtn, &QPushButton::clicked, this, &AudioPlayerDialog::togglePlayPause);
    connect(stopBtn, &QPushButton::clicked, m_player, &QMediaPlayer::stop);
    connect(m_seekSlider, &QSlider::sliderMoved, m_player, &QMediaPlayer::setPosition);
    connect(m_volumeSlider, &QSlider::valueChanged, this, [this](int v){
        m_audioOutput->setVolume(v / 100.0f);
    });
    connect(m_player, &QMediaPlayer::positionChanged, this, &AudioPlayerDialog::onPositionChanged);
    connect(m_player, &QMediaPlayer::durationChanged, this, &AudioPlayerDialog::onDurationChanged);
    connect(m_player, &QMediaPlayer::playbackStateChanged, this, &AudioPlayerDialog::onStateChanged);

    m_player->play();
}

void AudioPlayerDialog::togglePlayPause()
{
    m_player->playbackState() == QMediaPlayer::PlayingState
        ? m_player->pause() : m_player->play();
}
void AudioPlayerDialog::onPositionChanged(qint64 pos)
{
    m_seekSlider->setValue((int)pos);
    m_timeLabel->setText(fmtTime(pos) + " / " + fmtTime(m_player->duration()));
}
void AudioPlayerDialog::onDurationChanged(qint64 dur) { m_seekSlider->setRange(0, (int)dur); }
void AudioPlayerDialog::onStateChanged(QMediaPlayer::PlaybackState state)
{
    m_playPauseBtn->setText(state == QMediaPlayer::PlayingState ? "⏸ Pause" : "▶ Play");
}
QString AudioPlayerDialog::formatTime(qint64 ms) { return fmtTime(ms); }

// ─────────────────────────────────────────────────────────────────────────────
// VideoPlayerDialog
// ─────────────────────────────────────────────────────────────────────────────
VideoPlayerDialog::VideoPlayerDialog(const QString &filePath, QWidget *parent)
    : BaseMediaDialog(filePath, parent)
{
    setMinimumSize(720, 500);

    m_player      = new QMediaPlayer(this);
    m_audioOutput = new QAudioOutput(this);
    m_player->setAudioOutput(m_audioOutput);
    m_audioOutput->setVolume(0.7f);

    m_videoWidget = new QVideoWidget(this);
    m_player->setVideoOutput(m_videoWidget);
    m_player->setSource(QUrl::fromLocalFile(filePath));

    auto *root = new QVBoxLayout(this);
    buildTitleBar(root);
    root->addWidget(m_videoWidget, 1);

    // Seek
    m_seekSlider = new QSlider(Qt::Horizontal, this);
    m_seekSlider->setRange(0, 0);
    root->addWidget(m_seekSlider);

    m_timeLabel = new QLabel("0:00 / 0:00", this);
    m_timeLabel->setAlignment(Qt::AlignCenter);
    root->addWidget(m_timeLabel);

    // Controls
    auto *row       = new QHBoxLayout();
    m_playPauseBtn  = new QPushButton("▶ Play", this);
    auto *stopBtn   = new QPushButton("■ Stop", this);
    auto *volLabel  = new QLabel("🔊", this);
    m_volumeSlider  = new QSlider(Qt::Horizontal, this);
    m_volumeSlider->setRange(0, 100);
    m_volumeSlider->setValue(70);
    m_volumeSlider->setMaximumWidth(90);

    row->addWidget(m_playPauseBtn);
    row->addWidget(stopBtn);
    row->addStretch();
    row->addWidget(volLabel);
    row->addWidget(m_volumeSlider);
    root->addLayout(row);

    connect(m_playPauseBtn, &QPushButton::clicked, this, &VideoPlayerDialog::togglePlayPause);
    connect(stopBtn, &QPushButton::clicked, m_player, &QMediaPlayer::stop);
    connect(m_seekSlider, &QSlider::sliderMoved, m_player, &QMediaPlayer::setPosition);
    connect(m_volumeSlider, &QSlider::valueChanged, this, [this](int v){
        m_audioOutput->setVolume(v / 100.0f);
    });
    connect(m_player, &QMediaPlayer::positionChanged, this, &VideoPlayerDialog::onPositionChanged);
    connect(m_player, &QMediaPlayer::durationChanged, this, &VideoPlayerDialog::onDurationChanged);
    connect(m_player, &QMediaPlayer::playbackStateChanged, this, &VideoPlayerDialog::onStateChanged);

    m_player->play();
}

void VideoPlayerDialog::togglePlayPause()
{
    m_player->playbackState() == QMediaPlayer::PlayingState
        ? m_player->pause() : m_player->play();
}
void VideoPlayerDialog::onPositionChanged(qint64 pos)
{
    m_seekSlider->setValue((int)pos);
    m_timeLabel->setText(fmtTime(pos) + " / " + fmtTime(m_player->duration()));
}
void VideoPlayerDialog::onDurationChanged(qint64 dur) { m_seekSlider->setRange(0, (int)dur); }
void VideoPlayerDialog::onStateChanged(QMediaPlayer::PlaybackState state)
{
    m_playPauseBtn->setText(state == QMediaPlayer::PlayingState ? "⏸ Pause" : "▶ Play");
}
QString VideoPlayerDialog::formatTime(qint64 ms) { return fmtTime(ms); }

// ─────────────────────────────────────────────────────────────────────────────
// MediaDisplayManager
// ─────────────────────────────────────────────────────────────────────────────
MediaDisplayManager::MediaDisplayManager(QObject *parent) : QObject(parent) {}

MediaDisplayManager::MediaType MediaDisplayManager::detectType(const QString &filePath)
{
    static const QStringList images = {"jpg","jpeg","png","gif","bmp","tiff","webp"};
    static const QStringList audio  = {"mp3","wav","flac","ogg","aac","m4a","wma"};
    static const QStringList video  = {"mp4","mkv","avi","mov","wmv","m4v","webm"};

    QString ext = QFileInfo(filePath).suffix().toLower();
    if (images.contains(ext)) return MediaType::Image;
    if (audio.contains(ext))  return MediaType::Audio;
    if (video.contains(ext))  return MediaType::Video;
    return MediaType::Unknown;
}

void MediaDisplayManager::display(const QString &filePath, QWidget *parentWidget)
{
    if (filePath.isEmpty()) {
        QMessageBox::warning(parentWidget, "No Path",
                             "No file path is associated with this media.");
        return;
    }
    if (!QFileInfo::exists(filePath)) {
        QMessageBox::warning(parentWidget, "File Not Found",
                             "Could not find:\n" + filePath);
        return;
    }

    switch (detectType(filePath)) {
    case MediaType::Image: {
        auto *d = new ImageViewerDialog(filePath, parentWidget);
        d->show();
        break;
    }
    case MediaType::Audio: {
        auto *d = new AudioPlayerDialog(filePath, parentWidget);
        d->show();
        break;
    }
    case MediaType::Video: {
        auto *d = new VideoPlayerDialog(filePath, parentWidget);
        d->show();
        break;
    }
    default:
        QMessageBox::information(parentWidget, "Unsupported",
                                 "No viewer available for this file type.");
    }
}