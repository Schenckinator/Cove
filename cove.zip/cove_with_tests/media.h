#ifndef MEDIA_H
#define MEDIA_H

#include <QWidget>
#include <QListWidgetItem>
#include <QFileDialog>
#include <QDir>
#include <QFileInfo>
#include <QFile>
#include <QTextStream>
#include "MediaDisplayManager.h"

namespace Ui {
class Media;
}

class Media : public QWidget
{
    Q_OBJECT
public:
    explicit Media(QWidget *parent = nullptr);
    ~Media();

private slots:
    void on_uploadMedia_clicked();
    void on_deleteMedia_clicked();
    void on_ListofMedia_itemClicked(QListWidgetItem *item);
    void on_exit_clicked();
    void on_createPlaylist_clicked();
    void on_addToPlaylist_clicked();
    void on_searchBar_textChanged(const QString &query);

private:
    Ui::Media *ui;
    MediaDisplayManager *m_displayManager;

    // Returns the CSV file path for the currently logged-in user
    // e.g. "media_alice.csv"
    QString csvPath() const;

    void loadMediaFromCSV();
    void writeMediaToCSV(const QString &fileName, const QString &filePath);
    bool mediaExistsInCSV(const QString &filePath) const;
    void search(const QString &query);
    void displayMedia(const QStringList &mediaToDisplay);
    void setupDisplayManager();
    QString pathForTitle(const QString &title) const;
};

#endif // MEDIA_H
