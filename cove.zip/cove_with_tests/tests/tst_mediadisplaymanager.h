#pragma once
#include <QtTest/QtTest>
#include "../MediaDisplayManager.h"

// ---------------------------------------------------------------------------
// TestMediaDisplayManager
//
// MediaDisplayManager::detectType() is a pure static function that classifies
// a file path by extension.  It has no side-effects and requires no mocking,
// making it an ideal target for thorough unit tests.
//
// The display() method opens GUI dialogs and requires real media files, so it
// is left to manual / integration testing.
// ---------------------------------------------------------------------------
class TestMediaDisplayManager : public QObject
{
    Q_OBJECT

private slots:

    // ── Image extensions ─────────────────────────────────────────────────────

    void test_jpg_isImage()
    {
        QCOMPARE(MediaDisplayManager::detectType("photo.jpg"),
                 MediaDisplayManager::MediaType::Image);
    }

    void test_jpeg_isImage()
    {
        QCOMPARE(MediaDisplayManager::detectType("photo.jpeg"),
                 MediaDisplayManager::MediaType::Image);
    }

    void test_png_isImage()
    {
        QCOMPARE(MediaDisplayManager::detectType("screenshot.png"),
                 MediaDisplayManager::MediaType::Image);
    }

    void test_gif_isImage()
    {
        QCOMPARE(MediaDisplayManager::detectType("animation.gif"),
                 MediaDisplayManager::MediaType::Image);
    }

    void test_bmp_isImage()
    {
        QCOMPARE(MediaDisplayManager::detectType("bitmap.bmp"),
                 MediaDisplayManager::MediaType::Image);
    }

    void test_tiff_isImage()
    {
        QCOMPARE(MediaDisplayManager::detectType("scan.tiff"),
                 MediaDisplayManager::MediaType::Image);
    }

    // ── Audio extensions ──────────────────────────────────────────────────────

    void test_mp3_isAudio()
    {
        QCOMPARE(MediaDisplayManager::detectType("song.mp3"),
                 MediaDisplayManager::MediaType::Audio);
    }

    void test_wav_isAudio()
    {
        QCOMPARE(MediaDisplayManager::detectType("sound.wav"),
                 MediaDisplayManager::MediaType::Audio);
    }

    void test_flac_isAudio()
    {
        QCOMPARE(MediaDisplayManager::detectType("lossless.flac"),
                 MediaDisplayManager::MediaType::Audio);
    }

    void test_ogg_isAudio()
    {
        QCOMPARE(MediaDisplayManager::detectType("track.ogg"),
                 MediaDisplayManager::MediaType::Audio);
    }

    // ── Video extensions ──────────────────────────────────────────────────────

    void test_mp4_isVideo()
    {
        QCOMPARE(MediaDisplayManager::detectType("movie.mp4"),
                 MediaDisplayManager::MediaType::Video);
    }

    void test_mkv_isVideo()
    {
        QCOMPARE(MediaDisplayManager::detectType("film.mkv"),
                 MediaDisplayManager::MediaType::Video);
    }

    void test_avi_isVideo()
    {
        QCOMPARE(MediaDisplayManager::detectType("clip.avi"),
                 MediaDisplayManager::MediaType::Video);
    }

    void test_mov_isVideo()
    {
        QCOMPARE(MediaDisplayManager::detectType("recording.mov"),
                 MediaDisplayManager::MediaType::Video);
    }

    void test_wmv_isVideo()
    {
        QCOMPARE(MediaDisplayManager::detectType("screen.wmv"),
                 MediaDisplayManager::MediaType::Video);
    }

    void test_m4v_isVideo()
    {
        QCOMPARE(MediaDisplayManager::detectType("video.m4v"),
                 MediaDisplayManager::MediaType::Video);
    }

    // ── Unknown / edge cases ──────────────────────────────────────────────────

    void test_unknownExtension_isUnknown()
    {
        QCOMPARE(MediaDisplayManager::detectType("document.pdf"),
                 MediaDisplayManager::MediaType::Unknown);
    }

    void test_noExtension_isUnknown()
    {
        QCOMPARE(MediaDisplayManager::detectType("noextension"),
                 MediaDisplayManager::MediaType::Unknown);
    }

    void test_emptyPath_isUnknown()
    {
        QCOMPARE(MediaDisplayManager::detectType(QString()),
                 MediaDisplayManager::MediaType::Unknown);
    }

    void test_upperCaseExtension_isRecognised()
    {
        // Extensions should be case-insensitive
        auto type = MediaDisplayManager::detectType("PHOTO.JPG");
        QCOMPARE(type, MediaDisplayManager::MediaType::Image);
    }

    void test_pathWithDirectories_isHandled()
    {
        QCOMPARE(MediaDisplayManager::detectType("/home/user/music/track.mp3"),
                 MediaDisplayManager::MediaType::Audio);
    }

    void test_pathWithSpaces_isHandled()
    {
        QCOMPARE(MediaDisplayManager::detectType("/my videos/holiday clip.mp4"),
                 MediaDisplayManager::MediaType::Video);
    }
};
