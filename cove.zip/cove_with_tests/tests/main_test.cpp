#include <QApplication>
#include <QtTest/QtTest>

#include "tst_usersession.h"
#include "tst_playlistmanager.h"
#include "tst_login.h"
#include "tst_mediadisplaymanager.h"

// ---------------------------------------------------------------------------
// Single-binary runner: collects results from every test object and returns
// a non-zero exit code if any test fails.
// ---------------------------------------------------------------------------
int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    int status = 0;

    auto runTest = [&](QObject *obj) {
        status |= QTest::qExec(obj, argc, argv);
        delete obj;
    };

    runTest(new TestUserSession);
    runTest(new TestPlaylistManager);
    runTest(new TestLogin);
    runTest(new TestMediaDisplayManager);

    return status;
}
