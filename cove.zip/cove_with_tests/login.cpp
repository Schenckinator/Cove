#include "login.h"
#include "ui_login.h"
#include "covemenu.h"
#include "usersession.h"
#include "playlistmanager.h"

#include <QFile>
#include <QTextStream>
#include <QMessageBox>
#include <QCryptographicHash>

// ── helpers ──────────────────────────────────────────────────────────────────

// Simple SHA-256 hash so plain-text passwords are never stored on disk.
static QString hashPassword(const QString &password)
{
    return QString(QCryptographicHash::hash(
                       password.toUtf8(),
                       QCryptographicHash::Sha256).toHex());
}

// ── constructor / destructor ─────────────────────────────────────────────────

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->setStyleSheet("background-color: white;");

    // Clear placeholder text so the fields are truly empty on start-up
    ui->username->clear();
    ui->password->clear();
    ui->password->setEchoMode(QLineEdit::Password);
}

MainWindow::~MainWindow()
{
    delete ui;
}

// ── slots ────────────────────────────────────────────────────────────────────

void MainWindow::on_login_clicked()
{
    QString username = ui->username->text().trimmed();
    QString password = ui->password->text();

    if (username.isEmpty() || password.isEmpty()) {
        QMessageBox::warning(this, "Login Failed",
                             "Please enter both a username and a password.");
        return;
    }

    if (!validateCredentials(username, password)) {
        QMessageBox::warning(this, "Login Failed",
                             "Incorrect username or password.");
        return;
    }

    // Store the logged-in user globally so Media (and other widgets) can
    // derive the correct per-user CSV path.
    UserSession::instance().setUsername(username);

    // Load this user's playlists from their personal CSV
    PlaylistManager::instance().loadForUser(username);

    CoveMenu *covemenu = new CoveMenu();
    covemenu->show();
    this->close();
}

void MainWindow::on_registerButton_clicked()
{
    QString username = ui->username->text().trimmed();
    QString password = ui->password->text();

    if (username.isEmpty() || password.isEmpty()) {
        QMessageBox::warning(this, "Registration Failed",
                             "Please enter a username and a password.");
        return;
    }

    if (username.contains(',') || username.contains('"')) {
        QMessageBox::warning(this, "Registration Failed",
                             "Username must not contain commas or quotes.");
        return;
    }

    if (userExists(username)) {
        QMessageBox::warning(this, "Registration Failed",
                             "Username \"" + username + "\" is already taken.");
        return;
    }

    if (!registerUser(username, password)) {
        QMessageBox::critical(this, "Error",
                              "Could not write to users.csv. Check permissions.");
        return;
    }

    QMessageBox::information(this, "Registered",
                             "Account created for \"" + username + "\". You can now log in.");
}

void MainWindow::on_Exit_clicked()
{
    this->close();
}

// ── private helpers ──────────────────────────────────────────────────────────

bool MainWindow::validateCredentials(const QString &username,
                                     const QString &password) const
{
    QFile file("users.csv");
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
        return false;          // no users file yet → no valid credentials

    const QString hashed = hashPassword(password);

    QTextStream in(&file);
    while (!in.atEnd()) {
        QString line = in.readLine().trimmed();
        if (line.isEmpty() || line.startsWith('#'))
            continue;

        // Format: "username","password_hash"
        QString storedUser = line.section(',', 0, 0).remove('"').trimmed();
        QString storedHash = line.section(',', 1, 1).remove('"').trimmed();

        if (storedUser == username && storedHash == hashed) {
            file.close();
            return true;
        }
    }
    file.close();
    return false;
}

bool MainWindow::userExists(const QString &username) const
{
    QFile file("users.csv");
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
        return false;

    QTextStream in(&file);
    while (!in.atEnd()) {
        QString line = in.readLine().trimmed();
        if (line.isEmpty() || line.startsWith('#'))
            continue;
        QString storedUser = line.section(',', 0, 0).remove('"').trimmed();
        if (storedUser == username) {
            file.close();
            return true;
        }
    }
    file.close();
    return false;
}

bool MainWindow::registerUser(const QString &username,
                              const QString &password) const
{
    QFile file("users.csv");
    if (!file.open(QIODevice::Append | QIODevice::Text))
        return false;

    QTextStream out(&file);
    out << "\"" << username << "\","
        << "\"" << hashPassword(password) << "\"\n";
    file.close();
    return true;
}
