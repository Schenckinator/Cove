#include "covemenu.h"
#include "ui_covemenu.h"
#include "library.h"
#include "media.h"
#include "login.h"        // ← include here in .cpp, NOT in .h

CoveMenu::CoveMenu(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::CoveMenu)
{
    ui->setupUi(this);
    this->setStyleSheet("background-color: white;");
}

CoveMenu::~CoveMenu()
{
    delete ui;
}

void CoveMenu::on_Library_clicked()
{
    Library *library = new Library();
    library->show();
    this->close();
}

void CoveMenu::on_Media_clicked()
{
    Media *media = new Media();
    media->show();
    this->close();
}

void CoveMenu::on_Exit_clicked()
{
    MainWindow *login = new MainWindow();
    login->show();
    this->close();
}