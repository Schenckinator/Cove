#pragma once
#include <QtTest/QtTest>
#include <QFile>
#include <QTextStream>
#include <QCryptographicHash>
#include <QUuid>

// ---------------------------------------------------------------------------
// TestLogin
//
// login.cpp keeps validateCredentials / userExists / registerUser as private
// methods on MainWindow, which makes them hard to unit-test directly without
// a full widget.  We test the same *logic* by reimplementing the small helper
// functions here in the same way the production code does.
//
// This is a common Qt pattern: extract and verify the pure logic in isolation,
// leaving the slot tests for an integration / GUI test layer (e.g. QTest
// keyboard simulation or a UI automation tool).
// ---------------------------------------------------------------------------

// ── Helpers matching the production implementation exactly ──────────────────

static QString hashPassword(const QString &password)
{
    return QString(QCryptographicHash::hash(
                       password.toUtf8(),
                       QCryptographicHash::Sha256).toHex());
}

static bool validateCredentials(const QString &csvPath,
                                 const QString &username,
                                 const QString &password)
{
    QFile file(csvPath);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
        return false;

    const QString hashed = hashPassword(password);
    QTextStream in(&file);
    while (!in.atEnd()) {
        QString line = in.readLine().trimmed();
        if (line.isEmpty() || line.startsWith('#'))
            continue;
        QString storedUser = line.section(',', 0, 0).remove('"').trimmed();
        QString storedHash = line.section(',', 1, 1).remove('"').trimmed();
        if (storedUser == username && storedHash == hashed)
            return true;
    }
    return false;
}

static bool userExists(const QString &csvPath, const QString &username)
{
    QFile file(csvPath);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
        return false;

    QTextStream in(&file);
    while (!in.atEnd()) {
        QString line = in.readLine().trimmed();
        if (line.isEmpty() || line.startsWith('#'))
            continue;
        QString storedUser = line.section(',', 0, 0).remove('"').trimmed();
        if (storedUser == username)
            return true;
    }
    return false;
}

static bool registerUser(const QString &csvPath,
                          const QString &username,
                          const QString &password)
{
    QFile file(csvPath);
    if (!file.open(QIODevice::Append | QIODevice::Text))
        return false;

    QTextStream out(&file);
    out << '"' << username << "\"," << '"' << hashPassword(password) << "\"\n";
    return true;
}

// ── Test class ───────────────────────────────────────────────────────────────

class TestLogin : public QObject
{
    Q_OBJECT

private:
    QString m_csv;   // temp CSV path unique to this test run

private slots:

    void init()
    {
        m_csv = "test_users_" + QUuid::createUuid().toString(QUuid::Id128).left(8) + ".csv";
        // Ensure the file does not exist at the start of each test
        QFile::remove(m_csv);
    }

    void cleanup()
    {
        QFile::remove(m_csv);
    }

    // ── password hashing ────────────────────────────────────────────────────

    void test_hashPasswordIsDeterministic()
    {
        QCOMPARE(hashPassword("secret"), hashPassword("secret"));
    }

    void test_hashPasswordDiffersForDifferentInputs()
    {
        QVERIFY(hashPassword("abc") != hashPassword("xyz"));
    }

    void test_hashPasswordIsHex64Chars()
    {
        // SHA-256 → 32 bytes → 64 hex characters
        QCOMPARE(hashPassword("anything").length(), 64);
    }

    // ── validateCredentials ─────────────────────────────────────────────────

    void test_validateCredentials_missingFile_returnsFalse()
    {
        QVERIFY(!validateCredentials("/nonexistent/path/users.csv", "alice", "pass"));
    }

    void test_validateCredentials_correctPasswordReturnsTrue()
    {
        registerUser(m_csv, "alice", "mypassword");
        QVERIFY(validateCredentials(m_csv, "alice", "mypassword"));
    }

    void test_validateCredentials_wrongPasswordReturnsFalse()
    {
        registerUser(m_csv, "alice", "mypassword");
        QVERIFY(!validateCredentials(m_csv, "alice", "wrongpassword"));
    }

    void test_validateCredentials_unknownUserReturnsFalse()
    {
        registerUser(m_csv, "alice", "mypassword");
        QVERIFY(!validateCredentials(m_csv, "bob", "mypassword"));
    }

    void test_validateCredentials_emptyFileReturnsFalse()
    {
        // Create an empty file
        QFile f(m_csv);
        f.open(QIODevice::WriteOnly);
        f.close();
        QVERIFY(!validateCredentials(m_csv, "alice", "pass"));
    }

    void test_validateCredentials_caseSensitiveUsername()
    {
        registerUser(m_csv, "Alice", "pass");
        QVERIFY(!validateCredentials(m_csv, "alice", "pass"));
    }

    // ── userExists ───────────────────────────────────────────────────────────

    void test_userExists_missingFile_returnsFalse()
    {
        QVERIFY(!userExists("/nonexistent/path/users.csv", "alice"));
    }

    void test_userExists_knownUserReturnsTrue()
    {
        registerUser(m_csv, "charlie", "pw");
        QVERIFY(userExists(m_csv, "charlie"));
    }

    void test_userExists_unknownUserReturnsFalse()
    {
        registerUser(m_csv, "charlie", "pw");
        QVERIFY(!userExists(m_csv, "diana"));
    }

    // ── registerUser ─────────────────────────────────────────────────────────

    void test_registerUser_createsFile()
    {
        registerUser(m_csv, "eve", "pw");
        QVERIFY(QFile::exists(m_csv));
    }

    void test_registerUser_passwordStoredAsHash()
    {
        registerUser(m_csv, "frank", "plaintext");

        QFile f(m_csv);
        f.open(QIODevice::ReadOnly | QIODevice::Text);
        QString content = QTextStream(&f).readAll();
        f.close();

        // The plain-text password must NOT appear in the file
        QVERIFY(!content.contains("plaintext"));
        // The hash MUST appear
        QVERIFY(content.contains(hashPassword("plaintext")));
    }

    void test_registerUser_multipleUsersAppend()
    {
        registerUser(m_csv, "g", "pw1");
        registerUser(m_csv, "h", "pw2");

        QVERIFY(userExists(m_csv, "g"));
        QVERIFY(userExists(m_csv, "h"));
    }

    void test_fullLoginWorkflow()
    {
        // Register → check exists → validate correct → validate wrong
        QVERIFY(!userExists(m_csv, "ivan"));
        registerUser(m_csv, "ivan", "hunter2");
        QVERIFY(userExists(m_csv, "ivan"));
        QVERIFY(validateCredentials(m_csv, "ivan", "hunter2"));
        QVERIFY(!validateCredentials(m_csv, "ivan", "wrongpass"));
    }
};
