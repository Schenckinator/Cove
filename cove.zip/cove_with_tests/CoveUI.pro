QT += widgets core

CONFIG += c++17

# You can make your code fail to compile if it uses deprecated APIs.
# In order to do so, uncomment the following line.
#DEFINES += QT_DISABLE_DEPRECATED_BEFORE=0x060000    # disables all the APIs deprecated before Qt 6.0.0

#necessary for m1 mac compilation
QMAKE_CXXFLAGS += -include arm_acle.h
QT += multimedia multimediawidgets

SOURCES += \
    MediaDisplayManager.cpp \
    covemenu.cpp \
    library.cpp \
    login.cpp \
    main.cpp \
    media.cpp

HEADERS += \
    MediaDisplayManager.h \
    covemenu.h \
    library.h \
    login.h \
    media.h \
    playlistmanager.h \
    usersession.h

FORMS += \
    covemenu.ui \
    library.ui \
    login.ui \
    media.ui

# Default rules for deployment.
qnx: target.path = /tmp/$${TARGET}/bin
else: unix:!android: target.path = /opt/$${TARGET}/bin
!isEmpty(target.path): INSTALLS += target
