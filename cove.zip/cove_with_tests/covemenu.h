#ifndef COVEMENU_H
#define COVEMENU_H

#include <QWidget>

// Forward declare MainWindow instead of including login.h
class MainWindow;

namespace Ui {
class CoveMenu;
}

class CoveMenu : public QWidget {
    Q_OBJECT

public:
    explicit CoveMenu(QWidget *parent = nullptr);
    ~CoveMenu();

private slots:
    void on_Library_clicked();
    void on_Media_clicked();
    void on_Exit_clicked();

private:
    Ui::CoveMenu *ui;
};

#endif // COVEMENU_H