#include "library.h"
#include "ui_library.h"
#include "playlistmanager.h"
#include "covemenu.h"
#include "usersession.h"

#include <QMessageBox>
#include <QListWidgetItem>
#include <QInputDialog>
#include <QFile>
#include <QTextStream>

Library::Library(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Library)
    , m_displayManager(new MediaDisplayManager(this))
{
    ui->setupUi(this);
    this->setStyleSheet("background-color: white;");

    // Hide media-level buttons until a playlist is opened
    ui->backToPlaylists->setVisible(false);
    ui->removeMedia->setVisible(false);

    loadPlaylists();
}

Library::~Library()
{
    delete ui;
}

void Library::loadPlaylists()
{
    m_currentPlaylist.clear();
    ui->playlistWidget->clear();

    // Show playlist buttons, hide media buttons
    ui->refreshPlaylists->setVisible(true);
    ui->deletePlaylist->setVisible(true);
    ui->backToPlaylists->setVisible(false);
    ui->removeMedia->setVisible(false);

    QStringList playlists = PlaylistManager::instance().getPlaylists();

    if (playlists.isEmpty()) {
        ui->playlistWidget->addItem("No playlists yet — create one in Media!");
        return;
    }

    for (const QString &name : playlists) {
        int count = PlaylistManager::instance().getMedia(name).count();
        ui->playlistWidget->addItem(name + "  (" + QString::number(count) + " media)");
    }
}

void Library::showPlaylistContents(const QString &playlistName)
{
    m_currentPlaylist = playlistName;
    ui->playlistWidget->clear();

    // Hide playlist buttons, show media buttons
    ui->refreshPlaylists->setVisible(false);
    ui->deletePlaylist->setVisible(false);
    ui->backToPlaylists->setVisible(true);
    ui->removeMedia->setVisible(true);

    ui->playlistWidget->addItem("── " + playlistName + " ──");

    QStringList media = PlaylistManager::instance().getMedia(playlistName);

    if (media.isEmpty()) {
        ui->playlistWidget->addItem("This playlist is empty.");
    } else {
        for (const QString &m : media) {
            ui->playlistWidget->addItem(m);
        }
    }
}

// Double-click: open a playlist (from list view) or play media (from inside a playlist)
void Library::on_playlistWidget_itemDoubleClicked(QListWidgetItem *item)
{
    if (m_currentPlaylist.isEmpty()) {
        // Playlist list view — open the playlist
        QString full = item->text();
        if (!full.contains("  ("))
            return; // "no playlists" helper message — ignore

        QString playlistName = full.section("  (", 0, 0);
        showPlaylistContents(playlistName);
    } else {
        // Inside a playlist — play the media
        QString mediaTitle = item->text();
        if (mediaTitle.startsWith("──") || mediaTitle == "This playlist is empty.")
            return;

        QString path = pathForTitle(mediaTitle);
        if (path.isEmpty()) {
            QMessageBox::warning(this, "File Not Found",
                                 "Could not find the file for \"" + mediaTitle + "\".\n"
                                 "It may have been moved or deleted.");
            return;
        }
        m_displayManager->display(path, this);
    }
}

// Single-click: selection only — media opens on double-click to avoid double-open bug
void Library::on_playlistWidget_itemClicked(QListWidgetItem *item)
{
    Q_UNUSED(item);
    // Intentionally left empty: opening media on single-click caused it to open
    // twice because the single-click fires before the double-click, so closing
    // the first dialog would let the double-click event re-open it.
}

void Library::on_refreshPlaylists_clicked()
{
    loadPlaylists();
}

void Library::on_deletePlaylist_clicked()
{
    QListWidgetItem *selected = ui->playlistWidget->currentItem();

    if (!selected || !selected->text().contains("  (")) {
        QMessageBox::warning(this, "No Selection",
                             "Please select a playlist to delete.");
        return;
    }

    QString playlistName = selected->text().section("  (", 0, 0);

    QMessageBox::StandardButton reply = QMessageBox::question(
        this,
        "Confirm Delete",
        "Are you sure you want to delete \"" + playlistName + "\"?",
        QMessageBox::Yes | QMessageBox::No
        );

    if (reply == QMessageBox::Yes) {
        PlaylistManager::instance().deletePlaylist(playlistName);
        loadPlaylists();
        QMessageBox::information(this, "Deleted",
                                 "\"" + playlistName + "\" has been deleted.");
    }
}

void Library::on_backToPlaylists_clicked()
{
    loadPlaylists();
}

void Library::on_removeMedia_clicked()
{
    if (m_currentPlaylist.isEmpty()) {
        QMessageBox::warning(this, "No Playlist Open",
                             "Open a playlist first to remove media.");
        return;
    }

    QListWidgetItem *selected = ui->playlistWidget->currentItem();
    if (!selected) {
        QMessageBox::warning(this, "No Selection",
                             "Please select a media item to remove.");
        return;
    }

    QString mediaTitle = selected->text();
    if (mediaTitle.startsWith("──") || mediaTitle == "This playlist is empty.") {
        QMessageBox::warning(this, "Invalid Selection",
                             "Please select a media item to remove.");
        return;
    }

    QMessageBox::StandardButton reply = QMessageBox::question(
        this,
        "Confirm Remove",
        "Remove \"" + mediaTitle + "\" from \"" + m_currentPlaylist + "\"?",
        QMessageBox::Yes | QMessageBox::No
        );

    if (reply == QMessageBox::Yes) {
        PlaylistManager::instance().removeFromPlaylist(m_currentPlaylist, mediaTitle);
        showPlaylistContents(m_currentPlaylist);
    }
}

void Library::on_exit_clicked()
{
    CoveMenu *covemenu = new CoveMenu();
    covemenu->show();
    this->close();
}

// ── Private helpers ──────────────────────────────────────────────────────────

QString Library::pathForTitle(const QString &title) const
{
    QString csvFile = UserSession::instance().mediaCSVPath();
    QFile file(csvFile);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
        return {};

    QTextStream in(&file);
    while (!in.atEnd()) {
        QString line = in.readLine().trimmed();
        QString name = line.section(',', 0, 0).remove('"').trimmed();
        if (name == title)
            return line.section(',', 1, 1).remove('"').trimmed();
    }
    return {};
}
