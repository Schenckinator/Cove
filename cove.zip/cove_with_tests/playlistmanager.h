#ifndef PLAYLISTMANAGER_H
#define PLAYLISTMANAGER_H

#include <QString>
#include <QStringList>
#include <QMap>
#include <QFile>
#include <QTextStream>
#include <QDir>

// Per-user playlist manager.
// Call loadForUser(username) once after login; all subsequent operations
// read from and write to "playlists_<username>.csv".
//
// CSV format (one row per media entry):
//   "PlaylistName","MediaTitle"
// An empty playlist is represented by a single sentinel row:
//   "PlaylistName",""
class PlaylistManager
{
public:
    static PlaylistManager &instance() {
        static PlaylistManager pm;
        return pm;
    }

    // ── Session management ───────────────────────────────────────────────────

    // Call this right after login to load (or create) the user's playlists.
    void loadForUser(const QString &username) {
        m_username = username;
        m_playlists.clear();
        loadFromCSV();
    }

    // ── Playlist operations ──────────────────────────────────────────────────

    void createPlaylist(const QString &name) {
        if (!m_playlists.contains(name)) {
            m_playlists[name] = QStringList();
            saveToCSV();
        }
    }

    void deletePlaylist(const QString &name) {
        m_playlists.remove(name);
        saveToCSV();
    }

    void addToPlaylist(const QString &playlistName, const QString &media) {
        if (m_playlists.contains(playlistName) &&
            !m_playlists[playlistName].contains(media)) {
            m_playlists[playlistName].append(media);
            saveToCSV();
        }
    }

    void removeFromPlaylist(const QString &playlistName, const QString &media) {
        if (m_playlists.contains(playlistName)) {
            m_playlists[playlistName].removeAll(media);
            saveToCSV();
        }
    }

    QStringList getPlaylists() const { return m_playlists.keys(); }

    QStringList getMedia(const QString &playlistName) const {
        return m_playlists.value(playlistName);
    }

private:
    PlaylistManager() = default;

    QString m_username;
    QMap<QString, QStringList> m_playlists;

    QString csvPath() const {
        return "playlists_" + m_username + ".csv";
    }

    // ── Persistence ──────────────────────────────────────────────────────────

    void loadFromCSV() {
        QFile file(csvPath());
        if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
            return;  // No file yet — user has no playlists yet

        QTextStream in(&file);
        while (!in.atEnd()) {
            QString line = in.readLine().trimmed();
            if (line.isEmpty())
                continue;

            QString playlist = line.section(',', 0, 0).remove('"').trimmed();
            QString media    = line.section(',', 1, 1).remove('"').trimmed();

            if (!m_playlists.contains(playlist))
                m_playlists[playlist] = QStringList();

            // Empty media field is the sentinel for an empty playlist
            if (!media.isEmpty())
                m_playlists[playlist].append(media);
        }
        file.close();
    }

    void saveToCSV() {
        QFile file(csvPath());
        if (!file.open(QIODevice::WriteOnly | QIODevice::Text | QIODevice::Truncate))
            return;

        QTextStream out(&file);
        for (auto it = m_playlists.constBegin(); it != m_playlists.constEnd(); ++it) {
            const QString &name         = it.key();
            const QStringList &mediaList = it.value();

            if (mediaList.isEmpty()) {
                // Write sentinel so the playlist name survives a reload
                out << "\"" << name << "\",\"\"\n";
            } else {
                for (const QString &m : mediaList)
                    out << "\"" << name << "\",\"" << m << "\"\n";
            }
        }
        file.close();
    }
};

#endif // PLAYLISTMANAGER_H
