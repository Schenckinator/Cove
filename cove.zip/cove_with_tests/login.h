#ifndef LOGIN_H
#define LOGIN_H

#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow() override;

private slots:
    void on_login_clicked();
    void on_Exit_clicked();
    void on_registerButton_clicked();

private:
    Ui::MainWindow *ui;

    // Returns true if username/password match a row in users.csv
    bool validateCredentials(const QString &username, const QString &password) const;

    // Appends a new user row to users.csv
    bool registerUser(const QString &username, const QString &password) const;

    // Returns true if the username already exists in users.csv
    bool userExists(const QString &username) const;
};

#endif // LOGIN_H
