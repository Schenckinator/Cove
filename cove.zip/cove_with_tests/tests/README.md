# Cove – Unit Test Suite

## Overview

The tests live in `cove/tests/` and use the **Qt Test** framework that ships
with every Qt installation — no extra libraries needed.

```
cove/
├── tests/
│   ├── CoveTests.pro              ← qmake project for the test binary
│   ├── main_test.cpp              ← single-binary runner
│   ├── tst_usersession.cpp        ← UserSession singleton tests
│   ├── tst_playlistmanager.cpp    ← PlaylistManager in-memory + CSV tests
│   ├── tst_login.cpp              ← credential hashing / validation tests
│   └── tst_mediadisplaymanager.cpp← MediaDisplayManager.detectType() tests
```

### What is tested

| Test file | Class under test | What it covers |
|---|---|---|
| `tst_usersession.cpp` | `UserSession` | singleton identity, set/get username, CSV path derivation |
| `tst_playlistmanager.cpp` | `PlaylistManager` | create/delete playlists, add/remove media, CSV round-trip, user isolation |
| `tst_login.cpp` | `login.cpp` helpers | password hashing, credential validation, user registration |
| `tst_mediadisplaymanager.cpp` | `MediaDisplayManager::detectType` | extension detection for all supported media types |

---

## Building and running

### Qt Creator (recommended)

1. Open `cove/tests/CoveTests.pro` in Qt Creator  
   *(File → Open File or Project…)*
2. Configure the kit (same kit you use for the main app)
3. **Build** (`Ctrl+B`) then **Run** (`Ctrl+R`)
4. Results appear in the Application Output panel

### Command line (macOS / Linux)

```bash
cd cove/tests
qmake CoveTests.pro
make -j$(nproc)
./CoveTests -v2          # -v2 prints each test name; omit for terse output
```

### Command line (Windows with MSVC)

```bat
cd cove\tests
qmake CoveTests.pro
nmake
CoveTests.exe -v2
```

---

## Understanding the output

```
********* Start testing of TestUserSession *********
PASS   : TestUserSession::test_defaultUsernameIsEmpty()
PASS   : TestUserSession::test_setAndGetUsername()
...
Totals: 6 passed, 0 failed, 0 skipped
```

A non-zero exit code means at least one test failed — useful in CI pipelines.

---

## Adding new tests

1. Create `tst_myclass.cpp` in `tests/` following the pattern of existing files:
   - One `QObject` subclass with `Q_OBJECT`
   - Private slots named `test_*`
   - `init()` / `cleanup()` for per-test setup/teardown
2. Add the file to `SOURCES` in `CoveTests.pro`
3. Add `#include "tst_myclass.cpp"` and `runTest(new TestMyClass)` in `main_test.cpp`

---

## Notes on test design

* **No real media files required** — `detectType()` tests pass file path strings,
  not actual files.
* **Isolated CSV files** — `TestPlaylistManager` and `TestLogin` write to
  uniquely named temp CSV files (UUID-suffixed) and delete them in `cleanup()`.
  Running the tests never touches your real `users.csv` or playlist data.
* **No GUI interaction** — login slot behaviour (button clicks, dialogs) is not
  tested here; that requires either a UI automation layer or Qt Test's
  `QTest::keyClick` / `QTest::mouseClick` helpers, which is a natural next step.
