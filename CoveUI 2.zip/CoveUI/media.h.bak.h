#ifndef MEDIA_H
#define MEDIA_H

#include <QWidget>
#include <QListWidgetItem>

namespace Ui {
class Media;
}

class Media : public QWidget
{
    Q_OBJECT
public:
    explicit Media(QWidget *parent = nullptr);
    ~Media();

private slots:
    void on_uploadMedia_clicked();
    void on_deleteMedia_clicked();
    void on_ListofMedia_itemClicked(QListWidgetItem *item);
    void on_exit_clicked();

    void on_createPlaylist_clicked();

    void on_addToPlaylist_clicked();

private:
    Ui::Media *ui;
};

#endif // MEDIA_H