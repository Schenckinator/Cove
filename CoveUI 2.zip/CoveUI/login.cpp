#include "login.h"
#include "ui_login.h"
#include "covemenu.h"
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->setStyleSheet("background-color: white;");
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_login_clicked()
{
    CoveMenu *covemenu = new CoveMenu();
    covemenu->show();
    this->close();
}


void MainWindow::on_Exit_clicked()
{
    this->close();
}

