#pragma once
#include <QtTest/QtTest>
#include <QDir>
#include <QFile>
#include "../playlistmanager.h"

// ---------------------------------------------------------------------------
// TestPlaylistManager
//
// PlaylistManager is the most logic-rich class in Cove: it maintains an
// in-memory map and persists to / restores from a per-user CSV file.
//
// Strategy:
//   • Each test loads the manager under a throw-away username like
//     "testuser_<uuid>" so the CSV files land in the working directory and
//     never collide with real user data.
//   • cleanup() deletes those temporary CSV files after every test.
// ---------------------------------------------------------------------------
class TestPlaylistManager : public QObject
{
    Q_OBJECT

private:
    // Unique-enough name per test run
    QString m_testUser;

    void resetManager(const QString &user)
    {
        m_testUser = user;
        PlaylistManager::instance().loadForUser(user);
    }

    // Delete the CSV file created for a test user
    void removeCsv(const QString &user)
    {
        QString path = "playlists_" + user + ".csv";
        if (QFile::exists(path))
            QFile::remove(path);
    }

private slots:

    // ── setup / teardown ────────────────────────────────────────────────────

    void init()
    {
        // Each test gets its own isolated user so state cannot bleed
        m_testUser = "testuser_" + QUuid::createUuid().toString(QUuid::Id128).left(8);
        PlaylistManager::instance().loadForUser(m_testUser);
    }

    void cleanup()
    {
        removeCsv(m_testUser);
    }

    // ── tests ────────────────────────────────────────────────────────────────

    void test_freshUserHasNoPlaylists()
    {
        QVERIFY(PlaylistManager::instance().getPlaylists().isEmpty());
    }

    void test_createPlaylistAppearsInList()
    {
        PlaylistManager::instance().createPlaylist("Rock");
        QVERIFY(PlaylistManager::instance().getPlaylists().contains("Rock"));
    }

    void test_createDuplicatePlaylistIsIdempotent()
    {
        PlaylistManager::instance().createPlaylist("Jazz");
        PlaylistManager::instance().createPlaylist("Jazz");
        int count = PlaylistManager::instance().getPlaylists().count("Jazz");
        QCOMPARE(count, 1);
    }

    void test_deletePlaylistRemovesIt()
    {
        PlaylistManager::instance().createPlaylist("Pop");
        PlaylistManager::instance().deletePlaylist("Pop");
        QVERIFY(!PlaylistManager::instance().getPlaylists().contains("Pop"));
    }

    void test_deleteNonExistentPlaylistIsHarmless()
    {
        // Should not crash or corrupt state
        PlaylistManager::instance().deletePlaylist("DoesNotExist");
        QVERIFY(PlaylistManager::instance().getPlaylists().isEmpty());
    }

    void test_addMediaToPlaylist()
    {
        PlaylistManager::instance().createPlaylist("Favourites");
        PlaylistManager::instance().addToPlaylist("Favourites", "song.mp3");
        QStringList media = PlaylistManager::instance().getMedia("Favourites");
        QVERIFY(media.contains("song.mp3"));
    }

    void test_addDuplicateMediaIsIdempotent()
    {
        PlaylistManager::instance().createPlaylist("Mix");
        PlaylistManager::instance().addToPlaylist("Mix", "track.mp3");
        PlaylistManager::instance().addToPlaylist("Mix", "track.mp3");
        QCOMPARE(PlaylistManager::instance().getMedia("Mix").count("track.mp3"), 1);
    }

    void test_removeMediaFromPlaylist()
    {
        PlaylistManager::instance().createPlaylist("Chill");
        PlaylistManager::instance().addToPlaylist("Chill", "ambient.flac");
        PlaylistManager::instance().removeFromPlaylist("Chill", "ambient.flac");
        QVERIFY(!PlaylistManager::instance().getMedia("Chill").contains("ambient.flac"));
    }

    void test_removeMediaFromNonExistentPlaylistIsHarmless()
    {
        // Should not crash
        PlaylistManager::instance().removeFromPlaylist("Ghost", "anything.mp3");
    }

    void test_getMediaFromNonExistentPlaylistReturnsEmpty()
    {
        QStringList media = PlaylistManager::instance().getMedia("NoSuchPlaylist");
        QVERIFY(media.isEmpty());
    }

    void test_multiplePlaylistsCoexist()
    {
        PlaylistManager::instance().createPlaylist("A");
        PlaylistManager::instance().createPlaylist("B");
        PlaylistManager::instance().createPlaylist("C");
        QStringList lists = PlaylistManager::instance().getPlaylists();
        QVERIFY(lists.contains("A"));
        QVERIFY(lists.contains("B"));
        QVERIFY(lists.contains("C"));
        QCOMPARE(lists.size(), 3);
    }

    void test_persistenceRoundTrip()
    {
        // Write state through the manager
        PlaylistManager::instance().createPlaylist("Saved");
        PlaylistManager::instance().addToPlaylist("Saved", "file1.mp3");
        PlaylistManager::instance().addToPlaylist("Saved", "file2.mp3");

        // Reload from CSV (simulates app restart)
        PlaylistManager::instance().loadForUser(m_testUser);

        QStringList media = PlaylistManager::instance().getMedia("Saved");
        QVERIFY(media.contains("file1.mp3"));
        QVERIFY(media.contains("file2.mp3"));
        QCOMPARE(media.size(), 2);
    }

    void test_emptyPlaylistSurvivesRoundTrip()
    {
        // An empty playlist must be preserved after save/reload (sentinel row)
        PlaylistManager::instance().createPlaylist("Empty");

        PlaylistManager::instance().loadForUser(m_testUser);

        QVERIFY(PlaylistManager::instance().getPlaylists().contains("Empty"));
        QVERIFY(PlaylistManager::instance().getMedia("Empty").isEmpty());
    }

    void test_deletePlaylistPersists()
    {
        PlaylistManager::instance().createPlaylist("Temp");
        PlaylistManager::instance().addToPlaylist("Temp", "x.mp3");
        PlaylistManager::instance().deletePlaylist("Temp");

        // Reload — "Temp" must not come back
        PlaylistManager::instance().loadForUser(m_testUser);

        QVERIFY(!PlaylistManager::instance().getPlaylists().contains("Temp"));
    }

    void test_usersAreisolated()
    {
        // Data written for user A must not appear for user B
        PlaylistManager::instance().createPlaylist("Private");
        PlaylistManager::instance().addToPlaylist("Private", "secret.mp3");

        QString otherUser = m_testUser + "_other";
        PlaylistManager::instance().loadForUser(otherUser);

        QVERIFY(!PlaylistManager::instance().getPlaylists().contains("Private"));

        removeCsv(otherUser);   // tidy up the extra file
    }

    void test_addMediaToNonExistentPlaylistIsHarmless()
    {
        // Playlist does not exist yet — addToPlaylist should not crash
        PlaylistManager::instance().addToPlaylist("Ghost", "file.mp3");
        // The ghost playlist should not have been created either
        QVERIFY(!PlaylistManager::instance().getPlaylists().contains("Ghost"));
    }
};
