QT += testlib core widgets multimedia multimediawidgets

CONFIG += c++17 testcase
CONFIG -= app_bundle

TARGET = CoveTests

# Include paths so we can reach the app source
INCLUDEPATH += ..

# ── Sources under test (no main.cpp) ────────────────────────────────────────
SOURCES += \
    ../login.cpp \
    ../library.cpp \
    ../media.cpp \
    ../covemenu.cpp \
    ../MediaDisplayManager.cpp

HEADERS += \
    ../MediaDisplayManager.h \
    ../covemenu.h \
    ../library.h \
    ../login.h \
    ../media.h \
    ../playlistmanager.h \
    ../usersession.h

FORMS += \
    ../login.ui \
    ../library.ui \
    ../media.ui \
    ../covemenu.ui

# ── Test headers — listed here so MOC generates the vtable for Q_OBJECT ──────
HEADERS += \
    tst_usersession.h \
    tst_playlistmanager.h \
    tst_login.h \
    tst_mediadisplaymanager.h

# ── Test sources (thin .cpp files that just #include their matching .h) ───────
SOURCES += \
    tst_usersession.cpp \
    tst_playlistmanager.cpp \
    tst_login.cpp \
    tst_mediadisplaymanager.cpp \
    main_test.cpp

# macOS / M1 workaround (keep in sync with the main project)
QMAKE_CXXFLAGS += -include arm_acle.h
