#include "covemenu.h"
#include "ui_covemenu.h"
#include "library.h"
#include "media.h"
#include "login.h"
#include "usersession.h"
#include "playlistmanager.h"

CoveMenu::CoveMenu(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::CoveMenu)
{
    ui->setupUi(this);
    this->setStyleSheet("background-color: white;");

    // Personalise the welcome label with the logged-in username
    const QString user = UserSession::instance().username();
    if (!user.isEmpty())
        ui->welcome->setText("Welcome, " + user + "!");
}

CoveMenu::~CoveMenu()
{
    delete ui;
}

void CoveMenu::on_Library_clicked()
{
    Library *library = new Library();
    library->show();
    this->close();
}

void CoveMenu::on_Media_clicked()
{
    Media *media = new Media();
    media->show();
    this->close();
}

void CoveMenu::on_Exit_clicked()
{
    // Clear the session so the next login starts fresh
    UserSession::instance().setUsername("");
    PlaylistManager::instance().loadForUser("");  // clears in-memory playlists

    MainWindow *login = new MainWindow();
    login->show();
    this->close();
}