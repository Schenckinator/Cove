#pragma once
#include <QtTest/QtTest>
#include "../usersession.h"

// ---------------------------------------------------------------------------
// TestUserSession
//
// UserSession is a lightweight singleton that holds the logged-in username
// and derives per-user file paths.  No file I/O happens here, so there are
// no temporary files to clean up.
// ---------------------------------------------------------------------------
class TestUserSession : public QObject
{
    Q_OBJECT

private slots:

    // ── setup / teardown ────────────────────────────────────────────────────

    void init()
    {
        // Reset to a known blank state before every test
        UserSession::instance().setUsername(QString());
    }

    // ── tests ────────────────────────────────────────────────────────────────

    void test_defaultUsernameIsEmpty()
    {
        QVERIFY(UserSession::instance().username().isEmpty());
    }

    void test_setAndGetUsername()
    {
        UserSession::instance().setUsername("alice");
        QCOMPARE(UserSession::instance().username(), QString("alice"));
    }

    void test_mediaCSVPath_includesUsername()
    {
        UserSession::instance().setUsername("bob");
        QString path = UserSession::instance().mediaCSVPath();
        QVERIFY(path.contains("bob"));
        QVERIFY(path.startsWith("media_"));
        QVERIFY(path.endsWith(".csv"));
    }

    void test_mediaCSVPath_changesWithUser()
    {
        UserSession::instance().setUsername("user1");
        QString path1 = UserSession::instance().mediaCSVPath();

        UserSession::instance().setUsername("user2");
        QString path2 = UserSession::instance().mediaCSVPath();

        QVERIFY(path1 != path2);
    }

    void test_singletonReturnsSameInstance()
    {
        UserSession &a = UserSession::instance();
        UserSession &b = UserSession::instance();
        QVERIFY(&a == &b);
    }

    void test_overwriteUsername()
    {
        UserSession::instance().setUsername("first");
        UserSession::instance().setUsername("second");
        QCOMPARE(UserSession::instance().username(), QString("second"));
    }
};
