#include "library.h"
#include "ui_library.h"
#include "playlistmanager.h"
#include "covemenu.h"
#include <QMessageBox>
#include <QListWidgetItem>
#include <QInputDialog>

Library::Library(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Library)
{
    ui->setupUi(this);
    this->setStyleSheet("background-color: white;");

    // hide movie buttons on startup
    ui->backToPlaylists->setVisible(false);
    ui->removeMedia->setVisible(false);

    // dummy playlists
    PlaylistManager::instance().createPlaylist("Action Movies");
    PlaylistManager::instance().addToPlaylist("Action Movies", "The Dark Knight");
    PlaylistManager::instance().addToPlaylist("Action Movies", "The Matrix");
    PlaylistManager::instance().addToPlaylist("Action Movies", "Fight Club");

    PlaylistManager::instance().createPlaylist("Sci-Fi Favorites");
    PlaylistManager::instance().addToPlaylist("Sci-Fi Favorites", "Inception");
    PlaylistManager::instance().addToPlaylist("Sci-Fi Favorites", "Interstellar");
    PlaylistManager::instance().addToPlaylist("Sci-Fi Favorites", "The Matrix");

    PlaylistManager::instance().createPlaylist("Classic Cinema");
    PlaylistManager::instance().addToPlaylist("Classic Cinema", "The Godfather");
    PlaylistManager::instance().addToPlaylist("Classic Cinema", "Pulp Fiction");
    PlaylistManager::instance().addToPlaylist("Classic Cinema", "Goodfellas");
    PlaylistManager::instance().addToPlaylist("Classic Cinema", "The Shawshank Redemption");

    PlaylistManager::instance().createPlaylist("Weekend Watch");
    PlaylistManager::instance().addToPlaylist("Weekend Watch", "Forrest Gump");
    PlaylistManager::instance().addToPlaylist("Weekend Watch", "Inception");
    PlaylistManager::instance().addToPlaylist("Weekend Watch", "The Dark Knight");

    loadPlaylists();
}

Library::~Library()
{
    delete ui;
}

void Library::loadPlaylists()
{
    ui->playlistWidget->clear();

    // show playlist buttons, hide movie buttons
    ui->refreshPlaylists->setVisible(true);
    ui->deletePlaylist->setVisible(true);
    ui->backToPlaylists->setVisible(false);
    ui->removeMedia->setVisible(false);

    QStringList playlists = PlaylistManager::instance().getPlaylists();

    if (playlists.isEmpty()) {
        ui->playlistWidget->addItem("No playlists yet — create one in Media!");
        return;
    }

    for (const QString &name : playlists) {
        int count = PlaylistManager::instance().getMedia(name).count();
        ui->playlistWidget->addItem(name + "  (" + QString::number(count) + " media)");
    }

    ui->playlistWidget->setProperty("currentPlaylist", "");
}

void Library::showPlaylistContents(const QString &playlistName)
{
    ui->playlistWidget->clear();

    // hide playlist buttons, show movie buttons
    ui->refreshPlaylists->setVisible(false);
    ui->deletePlaylist->setVisible(false);
    ui->backToPlaylists->setVisible(true);
    ui->removeMedia->setVisible(true);

    ui->playlistWidget->setProperty("currentPlaylist", playlistName);
    ui->playlistWidget->addItem("── " + playlistName + " ──");

    QStringList media = PlaylistManager::instance().getMedia(playlistName);

    if (media.isEmpty()) {
        ui->playlistWidget->addItem("This playlist is empty.");
    } else {
        for (const QString &m : media) {
            ui->playlistWidget->addItem(m);
        }
    }
}

void Library::on_playlistWidget_itemDoubleClicked(QListWidgetItem *item)
{
    QString full = item->text();
    QString playlistName = full.section("  (", 0, 0);
    showPlaylistContents(playlistName);
}

void Library::on_refreshPlaylists_clicked()
{
    loadPlaylists();
}

void Library::on_deletePlaylist_clicked()
{
    QListWidgetItem *selected = ui->playlistWidget->currentItem();

    if (!selected) {
        QMessageBox::warning(this, "No Selection",
                             "Please select a playlist to delete.");
        return;
    }

    QString full = selected->text();
    QString playlistName = full.section("  (", 0, 0);

    QMessageBox::StandardButton reply = QMessageBox::question(
        this,
        "Confirm Delete",
        "Are you sure you want to delete \"" + playlistName + "\"?",
        QMessageBox::Yes | QMessageBox::No
        );

    if (reply == QMessageBox::Yes) {
        PlaylistManager::instance().deletePlaylist(playlistName);
        loadPlaylists();
        QMessageBox::information(this, "Deleted",
                                 "\"" + playlistName + "\" has been deleted.");
    }
}

void Library::on_backToPlaylists_clicked()
{
    loadPlaylists();
}

void Library::on_removeMedia_clicked()
{
    QString currentPlaylist = ui->playlistWidget->property("currentPlaylist").toString();

    if (currentPlaylist.isEmpty()) {
        QMessageBox::warning(this, "No Playlist Open",
                             "Double click a playlist first to view its movies.");
        return;
    }

    QListWidgetItem *selected = ui->playlistWidget->currentItem();

    if (!selected) {
        QMessageBox::warning(this, "No Selection",
                             "Please select a movie to remove.");
        return;
    }

    QString mediaTitle = selected->text();

    // ignore clicks on header or empty message
    if (mediaTitle.startsWith("──") || mediaTitle == "This playlist is empty.") {
        QMessageBox::warning(this, "Invalid Selection",
                             "Please select a media to remove.");
        return;
    }

    QMessageBox::StandardButton reply = QMessageBox::question(
        this,
        "Confirm Remove",
        "Remove \"" + mediaTitle + "\" from \"" + currentPlaylist + "\"?",
        QMessageBox::Yes | QMessageBox::No
        );

    if (reply == QMessageBox::Yes) {
        PlaylistManager::instance().removeFromPlaylist(currentPlaylist, mediaTitle);
        showPlaylistContents(currentPlaylist);
    }
}

void Library::on_exit_clicked()
{
    // replace CoveMenu with whatever your main menu class is called
    CoveMenu *covemenu = new CoveMenu();
    covemenu->show();
    this->close();
}