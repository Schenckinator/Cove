#ifndef LIBRARY_H
#define LIBRARY_H

#include <QWidget>
#include <QListWidgetItem>

namespace Ui { class Library; }

class Library : public QWidget
{
    Q_OBJECT
public:
    explicit Library(QWidget *parent = nullptr);
    ~Library();

private slots:
    void on_playlistWidget_itemDoubleClicked(QListWidgetItem *item); // ← double click
    void on_refreshPlaylists_clicked();
    void on_deletePlaylist_clicked();
    void on_exit_clicked();
    void on_removeMedia_clicked();
    void on_backToPlaylists_clicked();

private:
    Ui::Library *ui;
    void loadPlaylists();
    void showPlaylistContents(const QString &playlistName);
};

#endif