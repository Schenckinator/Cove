#include "media.h"
#include "ui_media.h"
#include "covemenu.h"
#include "playlistmanager.h"
#include "usersession.h"

#include <QLineEdit>
#include <QInputDialog>
#include <QListWidget>
#include <QListWidgetItem>
#include <QDebug>
#include <QMessageBox>
#include <QFileDialog>
#include <QDir>
#include <QFileInfo>
#include <QFile>
#include <QTextStream>

Media::Media(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Media)
{
    ui->setupUi(this);
    setupDisplayManager();

    connect(ui->ListofMedia, &QListWidget::itemDoubleClicked,
        this, [this](QListWidgetItem *item) {
            QString title = item->text();
            QString path  = pathForTitle(title);
            m_displayManager->display(path, this);
        });

    this->setStyleSheet("background-color: white;");

    // Load this user's media from their personal CSV instead of hardcoded list
    loadMediaFromCSV();
}

Media::~Media()
{
    delete ui;
}

// ── CSV path helper ──────────────────────────────────────────────────────────

// All read/write operations use this single method so switching users is trivial.
QString Media::csvPath() const
{
    return UserSession::instance().mediaCSVPath();
}

// ── Slots ────────────────────────────────────────────────────────────────────

void Media::on_uploadMedia_clicked()
{
    QString selectedPath = QFileDialog::getOpenFileName(
        this,
        "Select Media File",
        QDir::homePath(),
        "All Media (*.mp4 *.mkv *.avi *.mov *.wmv *.m4v *.mp3 *.wav *.flac *.ogg *.jpg *.jpeg *.png *.gif *.bmp *.tiff);;"
        "Image Files (*.jpg *.jpeg *.png *.gif *.bmp *.tiff);;"
        "Video Files (*.mp4 *.mkv *.avi *.mov *.wmv *.m4v);;"
        "Audio Files (*.mp3 *.wav *.flac *.ogg);;"
        "All Files (*)"
        );

    if (selectedPath.isEmpty())
        return;

    QFileInfo fileInfo(selectedPath);
    QString fileName   = fileInfo.fileName();
    QString nativePath = QDir::toNativeSeparators(selectedPath);

    if (mediaExistsInCSV(nativePath)) {
        QMessageBox::warning(this, "Duplicate Media",
                             "\"" + fileName + "\" is already in your library.");
        return;
    }

    writeMediaToCSV(fileName, nativePath);
    ui->ListofMedia->addItem(fileName);
}

void Media::on_ListofMedia_itemClicked(QListWidgetItem *item)
{
    qDebug() << "Selected:" << item->text();
}

void Media::on_deleteMedia_clicked()
{
    QListWidgetItem *selected = ui->ListofMedia->currentItem();
    if (!selected) {
        QMessageBox::warning(this, "No Selection", "Please select media to delete.");
        return;
    }

    QMessageBox::StandardButton reply = QMessageBox::question(
        this,
        "Confirm Delete",
        "Remove \"" + selected->text() + "\" from your library?",
        QMessageBox::Yes | QMessageBox::No
        );

    if (reply != QMessageBox::Yes)
        return;

    QString targetName = selected->text();

    // Re-write CSV without the deleted entry
    QFile file(csvPath());
    QStringList remaining;
    if (file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QTextStream in(&file);
        while (!in.atEnd()) {
            QString line = in.readLine().trimmed();
            QString name = line.section(',', 0, 0).remove('"').trimmed();
            if (name != targetName)
                remaining.append(line);
        }
        file.close();
    }

    if (file.open(QIODevice::WriteOnly | QIODevice::Text | QIODevice::Truncate)) {
        QTextStream out(&file);
        for (const QString &line : remaining)
            out << line << "\n";
        file.close();
    }

    delete selected;
}

void Media::on_exit_clicked()
{
    CoveMenu *covemenu = new CoveMenu();
    covemenu->show();
    this->close();
}

void Media::on_createPlaylist_clicked()
{
    bool ok;
    QString name = QInputDialog::getText(
        this, "Create Playlist", "Enter playlist name:",
        QLineEdit::Normal, "", &ok);

    if (ok && !name.isEmpty()) {
        PlaylistManager::instance().createPlaylist(name);
        QMessageBox::information(this, "Success",
                                 "Playlist \"" + name + "\" created!");
    }
}

void Media::on_addToPlaylist_clicked()
{
    QListWidgetItem *selected = ui->ListofMedia->currentItem();
    if (!selected) {
        QMessageBox::warning(this, "No Selection", "Please select a media item first.");
        return;
    }

    QStringList playlists = PlaylistManager::instance().getPlaylists();
    if (playlists.isEmpty()) {
        QMessageBox::warning(this, "No Playlists", "Create a playlist first.");
        return;
    }

    bool ok;
    QString chosen = QInputDialog::getItem(
        this, "Add to Playlist", "Select playlist:",
        playlists, 0, false, &ok);

    if (ok && !chosen.isEmpty()) {
        PlaylistManager::instance().addToPlaylist(chosen, selected->text());
        QMessageBox::information(this, "Added",
                                 "\"" + selected->text() + "\" added to " + chosen);
    }
}

void Media::on_searchBar_textChanged(const QString &query)
{
    search(query);
}

// ── Private helpers ──────────────────────────────────────────────────────────

void Media::loadMediaFromCSV()
{
    ui->ListofMedia->clear();
    QFile file(csvPath());
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
        return;   // No media yet for this user — that's fine

    QTextStream in(&file);
    while (!in.atEnd()) {
        QString line = in.readLine().trimmed();
        QString name = line.section(',', 0, 0).remove('"').trimmed();
        if (!name.isEmpty())
            ui->ListofMedia->addItem(name);
    }
    file.close();
}

void Media::writeMediaToCSV(const QString &fileName, const QString &filePath)
{
    QFile file(csvPath());
    if (!file.open(QIODevice::Append | QIODevice::Text)) {
        QMessageBox::critical(this, "File Error",
                              "Could not open " + csvPath() + " for writing.");
        return;
    }
    QTextStream out(&file);
    out << "\"" << fileName << "\","
        << "\"" << filePath << "\"\n";
    file.close();
}

bool Media::mediaExistsInCSV(const QString &filePath) const
{
    QFile file(csvPath());
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
        return false;

    QTextStream in(&file);
    while (!in.atEnd()) {
        QString line = in.readLine();
        QString existingPath = line.section(',', 1, 1).remove('"').trimmed();
        if (existingPath == filePath) {
            file.close();
            return true;
        }
    }
    file.close();
    return false;
}

void Media::search(const QString &query)
{
    ui->ListofMedia->clear();
    QFile file(csvPath());
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
        return;

    QTextStream in(&file);
    while (!in.atEnd()) {
        QString line = in.readLine().trimmed();
        QString name = line.section(',', 0, 0).remove('"').trimmed();
        if (name.isEmpty())
            continue;
        if (query.trimmed().isEmpty() ||
            name.contains(query.trimmed(), Qt::CaseInsensitive))
            ui->ListofMedia->addItem(name);
    }
    file.close();
}

void Media::displayMedia(const QStringList &mediaToDisplay)
{
    ui->ListofMedia->clear();
    ui->ListofMedia->addItems(mediaToDisplay);
}

void Media::setupDisplayManager()
{
    m_displayManager = new MediaDisplayManager(this);

    connect(ui->ListofMedia, &QListWidget::itemDoubleClicked,
            this, [this](QListWidgetItem *item) {
                QString path = pathForTitle(item->text());
                m_displayManager->display(path, this);
            });
}

QString Media::pathForTitle(const QString &title) const
{
    QFile file(csvPath());
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
        return {};
    QTextStream in(&file);
    while (!in.atEnd()) {
        QString line = in.readLine().trimmed();
        QString name = line.section(',', 0, 0).remove('"').trimmed();
        if (name == title)
            return line.section(',', 1, 1).remove('"').trimmed();
    }
    return {};
}
